/*****************************************************************************
  Name: Anne Marie Heidebreicht             NetID: alh1310
  Course: CSE 4714                          Assignment: Part 4
  Programming Environment: VS Code			File: parse_tree_nodes.h
  Purpose of File: Using my Part 3 submission as a starting point, create a
  TIPS Interpreter.
******************************************************************************/

#ifndef PARSE_TREE_NODES_H
#define PARSE_TREE_NODES_H

#include <iostream>
#include <vector>
#include <string>
#include "lexer.h"
#include <set>

using namespace std;
extern map<string, int> symbolTable;

// Forward declaration of nodes
class ProgramNode;
class BlockNode;
class StatementNode;
class AssignmentNode;
class CompoundNode;
class ReadNode;
class WriteNode;
class IfNode;
class WhileNode;
class ExprNode;
class NestedExprNode;
class SimpleExprNode;
class TermNode;
class FactorNode;
class IntLitNode;
class FloatLitNode;
class IdNode;
class NestedFactorNode;

// Forward declaration of operator<< for nodes
ostream &operator<<(ostream &os, ProgramNode &node);
ostream &operator<<(ostream &os, BlockNode &node);
ostream &operator<<(ostream &os, StatementNode &node);
ostream &operator<<(ostream &os, CompoundNode &node);
ostream &operator<<(ostream &os, ExprNode &node);
ostream &operator<<(ostream &os, SimpleExprNode &node);
ostream &operator<<(ostream &os, TermNode &node);
ostream &operator<<(ostream &os, FactorNode &node);

//*****************************************************************************
// Class FactorNode (Factor Node)
class FactorNode
{
public:
    virtual void printTo(ostream &os) = 0;
    virtual ~FactorNode() {}
    virtual int interpret() = 0;
};
ostream &operator<<(ostream &os, FactorNode &node)
{
    node.printTo(os);
    os << " )";
    return os;
}
//*****************************************************************************
// Class IntLitNode (Integer Literal Node)
class IntLitNode : public FactorNode
{
public:
    int int_literal = 0;
    IntLitNode(int value) // constructor
    {
        int_literal = value;
    }
    void printTo(ostream &os)
    {
        os << "factor( " << int_literal;
    }
    ~IntLitNode();
    int interpret();
};
// destructor for IntLitNode
IntLitNode::~IntLitNode()
{
    cout << "Deleting a factorNode" << endl;
}
int IntLitNode::interpret()
{
    return int_literal;
}
//*****************************************************************************
// Class FloatLitNode (Float Literal Node)
class FloatLitNode : public FactorNode
{
public:
    float float_literal = 0.0;
    FloatLitNode(float value) // constructor
    {
        float_literal = value;
    }
    void printTo(ostream &os)
    {
        os << "factor( " << float_literal;
    }
    ~FloatLitNode();
    int interpret();
};
// destructor for FloatLitNode
FloatLitNode::~FloatLitNode()
{
    cout << "Deleting a factorNode" << endl;
}
int FloatLitNode::interpret()
{
    return float_literal;
}
//*****************************************************************************
// Class IdNode (Identifier Node)
class IdNode : public FactorNode
{
public:
    string *id = nullptr;
    // constructor
    IdNode(string name)
    {
        id = new string(name);
    }

    void printTo(ostream &os)
    {
        os << "factor( " << *id;
    }
    ~IdNode();
    int interpret();
};
// destructor for IdNode
IdNode::~IdNode()
{
    cout << "Deleting a factorNode" << endl;
    delete id;
    id = nullptr;
}
int IdNode::interpret()
{
    return symbolTable[*id];
}
//*****************************************************************************
// Class NestedFactorNode (Nested Factor Node)
class NestedFactorNode : public FactorNode
{
public:
    int operand = 0;
    FactorNode *factorPtr = nullptr;
    // constructor
    NestedFactorNode(int op, FactorNode *fa)
    {
        this->operand = op;
        factorPtr = fa;
    }
    void printTo(ostream &os)
    {
        os << "factor( ";
        if (operand == TOK_NOT)
		{
            os << "NOT ";
		}
        else
		{
            os << "- ";
		}
        os << *factorPtr;
    }
    ~NestedFactorNode();
    int interpret();
};
// destructor for FactorNode
NestedFactorNode::~NestedFactorNode()
{
    cout << "Deleting a factorNode" << endl;
    delete factorPtr;
    factorPtr = nullptr;
}
int NestedFactorNode::interpret()
{
    if (operand == TOK_NOT)
    {
        return !factorPtr->interpret();
    }
    else
    {
        return -1 * factorPtr->interpret();
    }
}
//*****************************************************************************
// Class for TermNode (Term Node)
class TermNode
{
public:
    FactorNode *factorPtr = nullptr;
    // constructor
    TermNode(FactorNode *pFact)
    {
        factorPtr = pFact;
    }
    vector<int> restFactorOps;
    vector<FactorNode *> restFactors;
    ~TermNode();
    int interpret();
};
ostream &operator<<(ostream &os, TermNode &node)
{
    os << "term( ";
    os << *(node.factorPtr);

    int length = node.restFactorOps.size();
    for (int i = 0; i < length; ++i)
    {
        int op = node.restFactorOps[i];
        if (op == TOK_MULTIPLY)
		{
            os << " * ";
		}
        else if (op == TOK_DIVIDE)
		{
            os << " / ";
		}
        else
		{
            os << " AND ";
		}
        os << *(node.restFactors[i]);
    }
    os << " )";
    return os;
}
// destructor for TermNode
TermNode::~TermNode()
{
    cout << "Deleting a termNode" << endl;
    delete factorPtr;
    factorPtr = nullptr;
    int length = restFactorOps.size();
    for (int i = 0; i < length; ++i)
    {
        delete restFactors[i];
        restFactors[i] = nullptr;
    }
}
int TermNode::interpret()
{
    int result = 0;
    result = factorPtr->interpret();
    int length = restFactorOps.size();
    for (int i = 0; i < length; ++i)
    {
        int opCode = restFactorOps[i];
        if (opCode == TOK_MULTIPLY)
            result *= restFactors[i]->interpret();
        else if (opCode == TOK_DIVIDE)
            result /= restFactors[i]->interpret();
        else if (opCode == TOK_AND)
            result = result && restFactors[i]->interpret();
    }
    return result;
}
//*****************************************************************************
// Class SimpleExprNode (Simple Expression Node)
class SimpleExprNode
{
public:
    TermNode *termPtr = nullptr;
    // constructor
    SimpleExprNode(TermNode *pTerm)
    {
        termPtr = pTerm;
    }
    vector<int> restTermOps;
    vector<TermNode *> restTerms;
    ~SimpleExprNode();
    int interpret();
};
ostream &operator<<(ostream &os, SimpleExprNode &node)
{
    os << "simple_expression( ";
    os << *(node.termPtr);
    int length = node.restTermOps.size();
    for (int i = 0; i < length; ++i)
    {
        int op = node.restTermOps[i];
        if (op == TOK_PLUS)
            os << " + ";
        else if (op == TOK_MINUS)
            os << " - ";
        else
            os << " 0R ";
        os << *(node.restTerms[i]);
    }
    os << " )";
    return os;
}
// destructor for SimpleExprNode
SimpleExprNode::~SimpleExprNode()
{
    cout << "Deleting a simpleExpressionNode" << endl;
    delete termPtr;
    termPtr = nullptr;
    int length = restTermOps.size();
    for (int i = 0; i < length; ++i)
    {
        delete restTerms[i];
        restTerms[i] = nullptr;
    }
}
int SimpleExprNode::interpret()
{
    int result = 0;
    result = termPtr->interpret();
    int length = restTermOps.size();
    for (int i = 0; i < length; ++i)
    {
        int opCode = restTermOps[i];
        if (opCode == TOK_PLUS)
            result += restTerms[i]->interpret();
        else if (opCode == TOK_MINUS)
            result -= restTerms[i]->interpret();
        else if (opCode == TOK_OR)
            result = result || restTerms[i]->interpret();
    }
    return result;
}
//*****************************************************************************
// Class ExprNode (Expression Node)
class ExprNode
{
public:
    SimpleExprNode *simpleExpression1Ptr = nullptr;
    SimpleExprNode *simpleExpression2Ptr = nullptr;
    int operand;
    // constructor
    ExprNode(SimpleExprNode *pSimp1)
    {
        simpleExpression1Ptr = pSimp1;
    }
    // constructor for multiple expressions
    ExprNode(SimpleExprNode *pSimp1, int opCode, SimpleExprNode *pSimp2)
    {
        simpleExpression1Ptr = pSimp1;
        operand = opCode;
        simpleExpression2Ptr = pSimp2;
    }
    ~ExprNode();
    int interpret();
};
ostream &operator<<(ostream &os, ExprNode &node)
{
    os << *(node.simpleExpression1Ptr);
    if (node.operand == TOK_EQUALTO)
	{
        os << " = ";
	}
    else if (node.operand == TOK_LESSTHAN)
	{
        os << " < ";
	}
    else if (node.operand == TOK_GREATERTHAN)
	{
        os << " > ";
	}
    else if (node.operand == TOK_NOTEQUALTO)
	{
        os << " <> ";
	}
    if (node.simpleExpression2Ptr != nullptr)
	{
        os << *(node.simpleExpression2Ptr);
	}
    return os;
}
// destructor for ExprNode
ExprNode::~ExprNode()
{
    cout << "Deleting an expressionNode" << endl;
    delete simpleExpression1Ptr;
    simpleExpression1Ptr = nullptr;
    delete simpleExpression2Ptr;
    simpleExpression2Ptr = nullptr;
}
int ExprNode::interpret()
{
    int result;
    result = simpleExpression1Ptr->interpret();

    if (operand == TOK_EQUALTO)
    {
        if (result == simpleExpression2Ptr->interpret())
            result = 1;
        else
            result = 0;
    }
    else if (operand == TOK_LESSTHAN)
    {
        if (result < simpleExpression2Ptr->interpret())
        {
            result = 1;
        }
        else
            result = 0;
    }
    else if (operand == TOK_GREATERTHAN)
    {
        if (result > simpleExpression2Ptr->interpret())
            result = 1;
        else
            result = 0;
    }
    else if (operand == TOK_NOTEQUALTO)
    {
        if (result != simpleExpression2Ptr->interpret())
            result = 1;
        else
            result = 0;
    }
    return result;
}
//*****************************************************************************
// Class NestedExprNode (Nested Expression Node)
class NestedExprNode : public FactorNode
{
public:
    ExprNode *expressionPtr = nullptr;
    // constructor
    NestedExprNode(ExprNode *ex)
    {
        expressionPtr = ex;
    }
    void printTo(ostream &os)
    {
        os << "nested_expression( expression( " << *expressionPtr;
        os << " )";
    }
    ~NestedExprNode();
    int interpret();
};
// destructor for nestedExprNode
NestedExprNode::~NestedExprNode()
{
    cout << "Deleting a factorNode" << endl;

    delete expressionPtr;
    expressionPtr = nullptr;
}
int NestedExprNode::interpret()
{
    return expressionPtr->interpret();
}
//*****************************************************************************
// Class StatementNode (Statement Node)
class StatementNode
{
public:
    virtual void printTo(ostream &os) = 0;
    virtual ~StatementNode() {}
    virtual int interpret() = 0;
};
ostream &operator<<(ostream &os, StatementNode &node)
{
    node.printTo(os);
    return os;
}
//*****************************************************************************
// Class AssignmentNode (Assignment Node)
class AssignmentNode : public StatementNode
{
public:
    string *name = nullptr;
    ExprNode *expressionPtr = nullptr;
    // constructor
    AssignmentNode(string id, ExprNode *expr)
    {
        name = new string(id);
        expressionPtr = expr;
    }
    void printTo(ostream &os)
    {
        os << "Assignment " << *name << " := expression( ";
        os << *expressionPtr << " )" << endl;
    }
    ~AssignmentNode();
    int interpret();
};
// destructor for AssignmentNode
AssignmentNode::~AssignmentNode()
{
    cout << "Deleting an assignmentNode" << endl;
    delete name;
    name = nullptr;
    delete expressionPtr;
    expressionPtr = nullptr;
}
int AssignmentNode::interpret()
{
    return symbolTable[*name] = expressionPtr->interpret();
}
//*****************************************************************************
// Class ReadNode (Read Node)
class ReadNode : public StatementNode
{
public:
    string *name = nullptr;
    // constructor
    ReadNode(string id)
    {
        this->name = new string(id);
    }
    void printTo(ostream &os)
    {
        os << "Read Value " << *name << endl;
    }
    ~ReadNode();
    int interpret();
};
// destructor for ReadNode
ReadNode::~ReadNode()
{
    cout << "Deleting a readNode" << endl;
    delete name;
    name = nullptr;
}
int ReadNode::interpret()
{
    int inputNumber;
    cin >> inputNumber;
    symbolTable[*name] = inputNumber;
    return inputNumber;
}
//*****************************************************************************
// Class WriteNode (Write Node)
class WriteNode : public StatementNode
{
public:
    string *name = nullptr;
    int tokenNumber = 0;
    // constructor
    WriteNode(string id, int tokenNum)
    {
        name = new string(id);
        tokenNumber = tokenNum;
    }
    void printTo(ostream &os)
    {
        if (tokenNumber == TOK_STRINGLIT)
		{
            os << "Write String " << *name << endl;
		}
        else
		{
            os << "Write Value " << *name << endl;
		}
    }
    ~WriteNode();
    int interpret();
};
// destructor for WriteNode
WriteNode::~WriteNode()
{
    cout << "Deleting a writeNode" << endl;
    delete name;
    name = nullptr;
}
int WriteNode::interpret()
{
    if (this->tokenNumber == TOK_IDENT)
    {
        cout << symbolTable.at(*name) << endl;
    }
    else
    {
        string consoleOut = *name;
        consoleOut.erase(consoleOut.begin());
        consoleOut.pop_back();
        cout << consoleOut << endl;
    }
    return 0;
}
//*****************************************************************************
// Class IfNode (If Node)
class IfNode : public StatementNode
{
public:
    ExprNode *expressionPtr = nullptr;
    StatementNode *thenStatementPtr = nullptr;
    StatementNode *elseStatementPtr = nullptr;
    // constructor
    IfNode(ExprNode *expr, StatementNode *thenState)
    {
        expressionPtr = expr;
        thenStatementPtr = thenState;
    }
    IfNode(ExprNode *expr, StatementNode *thenState, StatementNode *elseState)
    {
        expressionPtr = expr;
        thenStatementPtr = thenState;
        elseStatementPtr = elseState;
    }
    void printTo(ostream &os)
    {
        os << "If expression( ";
        os << *expressionPtr << " )" << endl;
        os << "%%%%%%%% True Statement %%%%%%%%" << endl;
        os << *thenStatementPtr;
        os << "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n";

        if (elseStatementPtr != nullptr)
        {
            os << "%%%%%%%% False Statement %%%%%%%%" << endl;
            os << *elseStatementPtr;
            os << "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n";
        }
    }
    ~IfNode();
    int interpret();
};
// destructor for IfNode
IfNode::~IfNode()
{
    cout << "Deleting an ifNode" << endl;
    delete expressionPtr;
    expressionPtr = nullptr;
    delete thenStatementPtr;
    thenStatementPtr = nullptr;
    if (elseStatementPtr != nullptr)
    {
        delete elseStatementPtr;
        elseStatementPtr = nullptr;
    }
}
int IfNode::interpret()
{
    int result = expressionPtr->interpret();
    if (result != 0)
    {
        return thenStatementPtr->interpret();
    }
    if (elseStatementPtr != NULL)
    {
        return elseStatementPtr->interpret();
    }
    return 0;
}
//*****************************************************************************
// Class WhileNode (While Node)
class WhileNode : public StatementNode
{
public:
    ExprNode *expressionPtr = nullptr;
    StatementNode *loopBody = nullptr;
    // constructor
    WhileNode(ExprNode *expr, StatementNode *loopB)
    {
        expressionPtr = expr;
        loopBody = loopB;
    }
    void printTo(ostream &os)
    {
        os << "While expression( ";
        os << *expressionPtr << " )" << endl;
        os << "%%%%%%%% Loop Body %%%%%%%%" << endl;
        os << *loopBody;
        os << "%%%%%%%%%%%%%%%%%%%%%%%%%%%\n";
    }
    ~WhileNode();
    int interpret();
};
// destructor for WhileNode
WhileNode::~WhileNode()
{
    cout << "Deleting a whileNode" << endl;
    delete expressionPtr;
    expressionPtr = nullptr;
    delete loopBody;
    loopBody = nullptr;
}
int WhileNode::interpret()
{
    while (expressionPtr->interpret())
    {
        loopBody->interpret();
    }
    return 0;
}
//*****************************************************************************
// Class CompoundNode
class CompoundNode : public StatementNode
{
public:
    StatementNode *statementPtr = nullptr;
    // constructor
    CompoundNode(StatementNode *mystate)
    {
        statementPtr = mystate;
    }
    vector<StatementNode *> restStatements;
    void printTo(ostream &os)
    {
        os << "Begin Compound Statement" << endl;
        os << *statementPtr;
        int length = restStatements.size();
        for (int i = 0; i < length; ++i)
        {
            StatementNode *sts = restStatements[i];
            os << *sts;
        }
        os << "End Compound Statement" << endl;
    }
    ~CompoundNode();
    int interpret();
};
ostream &operator<<(ostream &os, CompoundNode &node)
{
    node.printTo(os);
    return os;
}
// destructor for CompoundNode
CompoundNode::~CompoundNode()
{
    cout << "Deleting a compoundNode" << endl;
    delete statementPtr;
    statementPtr = nullptr;
    int length = restStatements.size();
    for (int i = 0; i < length; ++i)
    {
        delete restStatements[i];
        restStatements[i] = nullptr;
    }
}
int CompoundNode::interpret()
{
    statementPtr->interpret();
    int length = restStatements.size();
    for (int i = 0; i < length; ++i)
    {
        restStatements[i]->interpret();
    }
    return 0;
}
//*****************************************************************************
// Class BlockNode (Block Node)
class BlockNode
{
public:
    CompoundNode *compoundStatement = nullptr;
    // constructor
    BlockNode(CompoundNode *compoundPtr)
    {
        this->compoundStatement = compoundPtr;
    }
    ~BlockNode();
    int interpret();
};
ostream &operator<<(ostream &os, BlockNode &node)
{
    os << *(node.compoundStatement);
    return os;
}
// destructor for BlockNode
BlockNode::~BlockNode()
{
    cout << "Deleting a blockNode" << endl;
    delete compoundStatement;
    compoundStatement = nullptr;
}
int BlockNode::interpret()
{
    return compoundStatement->interpret();
}
//*****************************************************************************
// Class ProgramNode (Program Node)
class ProgramNode
{
public:
    string *name = nullptr;
    BlockNode *block = nullptr;
    // constructor
    ProgramNode(string id, BlockNode *blk)
    {
        name = new string(id);
        block = blk;
    }
    ~ProgramNode();
    int interpret();
};
ostream &operator<<(ostream &os, ProgramNode &node)
{
    os << "Program Name " << *(node.name) << endl;
    os << *(node.block) << endl;
    return os;
}
// destructor for ProgramNode
ProgramNode::~ProgramNode()
{
    cout << "Deleting a programNode" << endl;
    delete name;
    name = nullptr;
    delete block;
    block = nullptr;
}
int ProgramNode::interpret()
{
    return block->interpret();
}
#endif