/*****************************************************************************
  Name: Anne Marie Heidebreicht             NetID: alh1310
  Course: CSE 4714                          Assignment: Part 4
  Programming Environment: VS Code          File: productions.h
  Purpose of File: Using my Part 3 submission as a starting point, create a
  TIPS Interpreter.
******************************************************************************/

#ifndef PRODUCTIONS_H
#define PRODUCTIONS_H

#include <iostream>
extern map<string, int> symbolTable;

int nextToken = 0; // token returned from yylex
int level = 0; // used to indent output to approximate parse tree
//*****************************************************************************
extern "C"
{
	// Instantiate global variables used by flex
    extern char *yytext; // text of current lexeme
    extern int yylex();  // the generated lexical analyzer
}
//*****************************************************************************
// Forward declarations of production parsing functions
bool first_of_program();
ProgramNode *program();
BlockNode *block();
CompoundNode *compound();
StatementNode *statement();
AssignmentNode *assignment();
ReadNode *read();
WriteNode *write();
IfNode *ifStatement();
WhileNode *whileStatement();
ExprNode *expression();
SimpleExprNode *simpleExpression();
TermNode *term();
FactorNode *factor();
//*****************************************************************************
// Forward declarations of functions that check whether the current token is
// in the first set of a production rule
bool first_of_program();
bool first_of_block();
bool first_of_statement();
bool first_of_assignment();
bool first_of_compound();
bool first_of_if();
bool first_of_while();
bool first_of_read();
bool first_of_write();
bool first_of_expression();
bool first_of_simple_expression();
bool first_of_term();
bool first_of_factor();
//*****************************************************************************
inline void indent()
{
    for (int i = 0; i < level; i++)
        cout << ("    ");
}

void output()
{
    indent();
    cout << "-->found " << yytext << endl;
}
//*****************************************************************************
int lex() // from parser.h in the Part_3_Example
{
    nextToken = yylex();
    if (nextToken == TOK_EOF)
    {
        yytext[0] = 'E';
        yytext[1] = 'O';
        yytext[2] = 'F';
        yytext[3] = 0;
    }
    return nextToken;
}
//*****************************************************************************
// <program> → TOK_PROGRAM TOK_IDENT TOK_SEMICOLON <block>
ProgramNode *program()
{
    ProgramNode *programPtr = nullptr;
    if (!first_of_program())
    {
        throw "3: 'PROGRAM' expected";
    }
    indent();
    cout << "enter <program>\n";
    ++level;
    output();
    lex();
    if (nextToken == TOK_IDENT)
    {
        string tempstr = yytext;
        output();
        lex();
        if (nextToken == TOK_SEMICOLON)
        {
            output();
            // block
            programPtr = new ProgramNode(tempstr, block());
        }
        else
        {
            throw "14: ';' expected";
        }
    }
    else
    {
        throw "2: identifier expected";
    }
    --level;
    indent();
    cout << "exit <program>\n";
    return programPtr;
}
//*****************************************************************************
// <block> → [ TOK_VAR TOK_IDENT TOK_COLON (TOK_INTEGER | TOK_REAL) TOK_SEMICOLON { TOK_IDENT TOK_COLON (TOK_INTEGER | TOK_REAL) TOK_SEMICOLON } ] <compound>
BlockNode *block()
{
    BlockNode *blockPtr = nullptr;
    bool isBegin = false;
    indent();
    cout << "enter <block>\n";
    ++level;
    lex();
    if (nextToken == TOK_VAR)
    {
        output();
        lex();
        do
        {
            if (nextToken == TOK_IDENT)
            {
                if (symbolTable.count(yytext)) // check for duplicate identifier
                {
                    throw "101: identifier declared twice";
                }
                symbolTable.insert(pair<string, int>(yytext, 0)); // insert into table
                output();
                lex();
                if (nextToken == TOK_COLON)
                {
                    output();
                    lex();
                    if (nextToken == TOK_INTEGER || nextToken == TOK_REAL)
                    {
                        output();
                        lex();
                        if (nextToken == TOK_SEMICOLON)
                        {
                            output();
                            lex();
                            cout << endl;
                            if (nextToken == TOK_IDENT)
                            {
                                isBegin = false;
                            }
                            else if (nextToken == TOK_BEGIN)
                            {
                                isBegin = true;
                                // compound statement
                                blockPtr = new BlockNode(compound());
                            }
                            else
                            {
                                throw "17: 'BEGIN' expected";
                            }
                        }
                        else
                        {
                            throw "14: ';' expected";
                        }
                    }
                    else
                    {
                        throw "10: error in type";
                    }
                }
                else
                {
                    throw "5: ':' expected";
                }
            }
            else
            {
                throw "2: identifier expected";
            }
        } 
        while (isBegin == false);
    }
    else if (nextToken == TOK_BEGIN)
    {
        // compound statement
        blockPtr = new BlockNode(compound());
    }
    else
    {
        throw "18: error in declaration part OR 17: 'BEGIN' expected";
    }
    --level;
    indent();
    cout << "exit <block>\n";
    return blockPtr;
}
//*****************************************************************************
// <statement> → <assignment> | <compound> | <if> | <while> | <read> | <write>
StatementNode *statement()
{
    StatementNode *statementPtr = nullptr;
    indent();
    cout << "enter <statement>\n";
    ++level;
    if (nextToken == TOK_IDENT)
    {
        // assignment
        statementPtr = assignment();
    }
    else if (nextToken == TOK_BEGIN)
    {
        // compound statement
        statementPtr = compound();
    }
    else if (nextToken == TOK_READ)
    {
        // read
        statementPtr = read();
    }
    else if (nextToken == TOK_WRITE)
    {
        // write
        statementPtr = write();
    }
    else if (nextToken == TOK_IF)
    {
        // if
        statementPtr = ifStatement();
    }
    else if (nextToken == TOK_WHILE)
    {
        // while
        statementPtr = whileStatement();
    }
    else
    {
        throw "900: illegal type of statement";
    }
    --level;
    indent();
    cout << "exit <statement>\n";
    return statementPtr;
}
//*****************************************************************************
// <assignment> → TOK_IDENT TOK_ASSIGN <expression>
AssignmentNode *assignment()
{
    AssignmentNode *assignmentPtr = nullptr;
    indent();
    cout << "enter <assignment>\n";
    if (!symbolTable.count(yytext)) // check for no identifier
    {
        throw "104: identifier not declared";
    }
    string tempstr = yytext;
    ++level;
    output();
    lex();
    if (nextToken == TOK_ASSIGN)
    {
        output();
        lex();
        // expression
        assignmentPtr = new AssignmentNode(tempstr, expression());
        --level;
        indent();
        cout << "exit <assignment>\n";
    }
    else
    {
        throw "51: ':=' expected";
    }
    return assignmentPtr;
}
//*****************************************************************************
// <compound> → TOK_BEGIN <statement> { TOK_SEMICOLON <statement> } TOK_END
CompoundNode *compound()
{
    CompoundNode *compoundPtr = nullptr;
    indent();
    cout << "enter <compound_statement>\n";
    ++level;
    output();
    lex();
    //statement();
    compoundPtr = new CompoundNode(statement());
    while (nextToken == TOK_SEMICOLON)
    {
        output();
        lex();
        //statement
        compoundPtr->restStatements.push_back(statement());
    }
    if (nextToken == TOK_END)
    {
        output();
        lex();
    }
    else
    {
        throw "13: 'END' expected";
    }
    --level;
    indent();
    cout << "exit <compound_statement>\n";
    return compoundPtr;
}
//*****************************************************************************
// <if> → TOK_IF <expression> TOK_THEN <statement> [ TOK_ELSE <statement> ]
IfNode *ifStatement()
{
    IfNode *ifPtr = nullptr;
    indent();
    cout << "enter <if statement>\n";
    ++level;
    output();
    lex();
    // expression
    ExprNode *expressionPtr = expression();
    if (nextToken == TOK_THEN)
    {
        output();
        lex();
        // statement
        StatementNode *statementPtr = statement();
        ifPtr = new IfNode(expressionPtr, statementPtr);
        if (nextToken == TOK_ELSE)
        {
            output();
            lex();
            // statement
            ifPtr = new IfNode(expressionPtr, statementPtr, statement());
        }
    }
    else
    {
        throw "52: 'THEN' expected";
    }
    --level;
    indent();
    cout << "exit <if statement>\n";
    return ifPtr;
}
//*****************************************************************************
// <while> → TOK_WHILE <expression> <statement>
WhileNode *whileStatement()
{
    WhileNode *whilePtr = nullptr;
    indent();
    cout << "enter <while statement>\n";
    ++level;
    output();
    lex();
    // expression
    ExprNode *pEx = expression();
    // statement
    whilePtr = new WhileNode(pEx, statement());
    --level;
    indent();
    cout << "exit <while statement>\n";
    return whilePtr;
}
//*****************************************************************************
// <read> → TOK_READ TOK_OPENPAREN TOK_IDENT TOK_CLOSEPAREN
ReadNode *read()
{
    ReadNode *readPtr = nullptr;
    indent();
    cout << "enter <read>\n";
    ++level;
    output();
    lex();
    if (nextToken == TOK_OPENPAREN)
    {
        output();
        lex();
        if (nextToken == TOK_IDENT)
        {
            if (!symbolTable.count(yytext)) // check for no identifier
            {
                throw "104: identifier not declared";
            }
            readPtr = new ReadNode(yytext);
            output();
            lex();
            if (nextToken == TOK_CLOSEPAREN)
            {
                output();
                lex();
            }
            else
            {
                throw "4: ')' expected";
            }
        }
        else
        {
            throw "2: identifier expected";
        }
    }
    else
    {
        throw "9: '(' expected";
    }
    --level;
    indent();
    cout << "exit <read>\n";
    return readPtr;
}
//*****************************************************************************
// <write> → TOK_WRITE TOK_OPENPAREN ( TOK_IDENT | TOK_STRINGLIT ) TOK_CLOSEPAREN
WriteNode *write()
{
    WriteNode *writePtr = nullptr;
    indent();
    cout << "enter <write>\n";
    ++level;
    output();
    lex();
    if (nextToken == TOK_OPENPAREN)
    {
        output();
        lex();
        if (nextToken == TOK_IDENT)
        {

            if (!symbolTable.count(yytext)) // check for no identifier
            {
                throw "104: identifier not declared";
            }
            writePtr = new WriteNode(yytext, nextToken);
            output();
            lex();
        }
        else if (nextToken == TOK_STRINGLIT)
        {
            output();
            writePtr = new WriteNode(yytext, nextToken);
            lex();
        }
        else
        {
            throw "134: illegal type of operand(s)";
        }
        if (nextToken == TOK_CLOSEPAREN)
        {

            output();
            lex();
        }
        else
        {
            throw "4: ')' expected";
        }
    }
    else
    {
        throw "9: '(' expected";
    }
    --level;
    indent();
    cout << "exit <write>\n";
    return writePtr;
}
//*****************************************************************************
// <expression> → <simple expression>  [ ( TOK_EQUALTO | TOK_LESSTHAN | TOK_GREATERTHAN | TOK_NOTEQUALTO ) <simple expression> ]
ExprNode *expression()
{
    ExprNode *expressionPtr = nullptr;
    indent();
    cout << "enter <expression>\n";
    ++level;
    if (nextToken != TOK_INTLIT && nextToken != TOK_FLOATLIT && nextToken != TOK_IDENT && nextToken != TOK_OPENPAREN && nextToken != TOK_NOT && nextToken != TOK_MINUS)
    {
        throw "144: illegal type of expression";
    }
    // simpleExpression
    SimpleExprNode *simpleExpressionPtr = simpleExpression();
    expressionPtr = new ExprNode(simpleExpressionPtr);
    if (nextToken == TOK_EQUALTO || nextToken == TOK_LESSTHAN || nextToken == TOK_GREATERTHAN || nextToken == TOK_NOTEQUALTO)
    {
        output();
        int x = nextToken;
        lex();
        // simpleExpression
        expressionPtr = new ExprNode(simpleExpressionPtr, x, simpleExpression());
    }
    --level;
    indent();
    cout << "exit <expression>\n";
    return expressionPtr;
}
//*****************************************************************************
// <simple expression> → <term> { ( TOK_PLUS | TOK_MINUS | TOK_OR ) <term> }
SimpleExprNode *simpleExpression()
{
    SimpleExprNode *simpleExpressionPtr = nullptr;
    indent();
    cout << "enter <simple expression>\n";
    ++level;
    if (nextToken != TOK_INTLIT && nextToken != TOK_FLOATLIT && nextToken != TOK_IDENT && nextToken != TOK_OPENPAREN && nextToken != TOK_NOT && nextToken != TOK_MINUS)
    {
        throw "901: illegal type of simple expression";
    }
    // term
    simpleExpressionPtr = new SimpleExprNode(term());
    while (nextToken == TOK_PLUS || nextToken == TOK_MINUS || nextToken == TOK_OR)
    {
        output();
        simpleExpressionPtr->restTermOps.push_back(nextToken);
        lex();
        // term
        simpleExpressionPtr->restTerms.push_back(term());
    }
    --level;
    indent();
    cout << "exit <simple expression>\n";
    return simpleExpressionPtr;
}
//*****************************************************************************
// <term> → <factor> { ( TOK_MULTIPLY | TOK_DIVIDE | TOK_AND ) <factor> }
TermNode *term()
{
    TermNode *termPtr = nullptr;
    indent();
    cout << "enter <term>\n";
    ++level;
    if (nextToken != TOK_INTLIT && nextToken != TOK_FLOATLIT && nextToken != TOK_IDENT && nextToken != TOK_OPENPAREN && nextToken != TOK_NOT && nextToken != TOK_MINUS)
    {
        throw "902: illegal type of term";
    }
    // factor
    termPtr = new TermNode(factor());
    while (nextToken == TOK_MULTIPLY || nextToken == TOK_DIVIDE || nextToken == TOK_AND)
    {
        output();
        termPtr->restFactorOps.push_back(nextToken);
        lex();
        // factor
        termPtr->restFactors.push_back(factor());
    }
    --level;
    indent();
    cout << "exit <term>\n";
    return termPtr;
}
//*****************************************************************************
// <factor> → TOK_INTLIT | TOK_FLOATLIT | TOK_IDENT |
FactorNode *factor()
{
    FactorNode *factorPtr = nullptr;
    indent();
    cout << "enter <factor>\n";
    ++level;
    if (nextToken == TOK_INTLIT)
    {
        factorPtr = new IntLitNode(stoi(yytext)); // Source: https://cplusplus.com/reference/string/
        output();
        lex();
    }
    else if (nextToken == TOK_FLOATLIT)
    {
        factorPtr = new FloatLitNode(stof(yytext)); // Source: https://cplusplus.com/reference/string/
        output();
        lex();
    }
    else if (nextToken == TOK_IDENT)
    {
        if (!symbolTable.count(yytext)) // check for no identifier
        {
            throw "104: identifier not declared";
        }
        factorPtr = new IdNode(yytext);
        output();
        lex();
    }
    else if (nextToken == TOK_OPENPAREN)
    {
        output();
        lex();
        // expression
        factorPtr = new NestedExprNode(expression());
        if (nextToken == TOK_CLOSEPAREN)
        {
            output();
            lex();
        }
        else
        {
            throw "4: ')' expected";
        }
    }
    else if (nextToken == TOK_NOT)
    {
        int x = nextToken;
        output();
        lex();
        // factor
        factorPtr = new NestedFactorNode(x, factor());
    }
    else if (nextToken == TOK_MINUS)
    {
        int x = nextToken;
        output();
        lex();
        // factor
        factorPtr = new NestedFactorNode(x, factor());
    }
    else
    {
        throw "903: illegal type of factor";
    }
    --level;
    indent();
    cout << "exit <factor>\n";
    return factorPtr;
}
//*****************************************************************************
bool first_of_program(void) {
    return nextToken = TOK_PROGRAM;
}
bool first_of_block(void) {
    return nextToken == TOK_VAR || nextToken == TOK_BEGIN;
}
bool first_of_statement(void) {
    return nextToken == TOK_IDENT || nextToken == TOK_BEGIN || nextToken == TOK_IF || nextToken == TOK_WHILE || nextToken == TOK_READ || nextToken == TOK_WRITE;
}
bool first_of_assignment(void) {
    return nextToken == TOK_IDENT;
}
bool first_of_compound(void) {
    return nextToken == TOK_BEGIN;
}
bool first_of_if(void) {
    return nextToken == TOK_IF;
}
bool first_of_while(void) {
    return nextToken == TOK_WHILE;
}
bool first_of_read(void) {
    return nextToken == TOK_READ;
}
bool first_of_write(void) {
    return nextToken == TOK_WRITE;
}
bool first_of_expression(void) {
    return nextToken == TOK_INTLIT || nextToken == TOK_FLOATLIT || nextToken == TOK_IDENT || nextToken == TOK_OPENPAREN || TOK_NOT || TOK_MINUS;
}
bool first_of_simple_expression(void) {
    return nextToken == TOK_INTLIT || nextToken == TOK_FLOATLIT || nextToken == TOK_IDENT || nextToken == TOK_OPENPAREN || TOK_NOT || TOK_MINUS;
}
bool first_of_term(void) {
    return nextToken == TOK_INTLIT || nextToken == TOK_FLOATLIT || nextToken == TOK_IDENT || nextToken == TOK_OPENPAREN || TOK_NOT || TOK_MINUS;
}
bool first_of_factor(void) {
    return nextToken == TOK_INTLIT || nextToken == TOK_FLOATLIT || nextToken == TOK_IDENT || nextToken == TOK_OPENPAREN || TOK_NOT || TOK_MINUS;
}
//*****************************************************************************
#endif