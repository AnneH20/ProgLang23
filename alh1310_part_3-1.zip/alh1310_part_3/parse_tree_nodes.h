/*****************************************************************************
  Name: Anne Marie Heidebreicht             NetID: alh1310
  Course: CSE 4714                          Assignment: Part 3
  Programming Environment: VS Code			File: parse_tree_nodes.h
  Purpose of File: Using my Part 2 submission as a starting point, create a
  parse tree for the TIPS programs. Basically a bunch of pointers and nodes.
******************************************************************************/

#ifndef PARSE_TREE_NODES_H
#define PARSE_TREE_NODES_H

#include <iostream>
#include <vector>
#include <string>
#include "lexer.h"
#include <set>

using namespace std;
extern set<string> symbolTable;

// Forward declaration of nodes
class ProgramNode;
class BlockNode;
class StatementNode;
class AssignmentNode;
class CompoundNode;
class ReadNode;
class WriteNode;
class IfNode;
class WhileNode;
class ExprNode;
class NestedExprNode;
class SimpleExprNode;
class TermNode;
class FactorNode;
class IntLitNode;
class FloatLitNode;
class IdNode;
class NestedFactorNode;

// Forward declaration of operator<< for nodes
ostream &operator<<(ostream &os, ProgramNode &node);
ostream &operator<<(ostream &os, BlockNode &node);
ostream &operator<<(ostream &os, StatementNode &node);
ostream &operator<<(ostream &os, CompoundNode &node);
ostream &operator<<(ostream &os, ExprNode &node);
ostream &operator<<(ostream &os, SimpleExprNode &node);
ostream &operator<<(ostream &os, TermNode &node);
ostream &operator<<(ostream &os, FactorNode &node);

//*****************************************************************************
// Class FactorNode (Factor Node)
class FactorNode
{
public:
    virtual void printTo(ostream &os) = 0;
    virtual ~FactorNode() {}
};
ostream &operator<<(ostream &os, FactorNode &node)
{
    node.printTo(os);
    os << " )";
    return os;
}
//*****************************************************************************
// Class IntLitNode (Integer Literal Node)
class IntLitNode : public FactorNode
{
public:
    int int_literal = 0;
    IntLitNode(int value) // constructor
    {
        int_literal = value;
    }
    void printTo(ostream &os)
    {
        os << "factor( " << int_literal;
    }
    ~IntLitNode();
};
// destructor for IntLitNode
IntLitNode::~IntLitNode()
{
    cout << "Deleting a factorNode" << endl;
}
//*****************************************************************************
// Class FloatLitNode (Float Literal Node)
class FloatLitNode : public FactorNode
{
public:
    float float_literal = 0.0;
    FloatLitNode(float value) // constructor
    {
        float_literal = value;
    }
    void printTo(ostream &os)
    {
        os << "factor( " << float_literal;
    }
    ~FloatLitNode();
};
// destructor for FloatLitNode
FloatLitNode::~FloatLitNode()
{
    cout << "Deleting a factorNode" << endl;
}
//*****************************************************************************
// Class IdNode (Identifier Node)
class IdNode : public FactorNode
{
public:
    string *id = nullptr;
    // constructor
    IdNode(string name)
    {
        id = new string(name);
    }

    void printTo(ostream &os)
    {
        os << "factor( " << *id;
    }
    ~IdNode();
};
// destructor for IdNode
IdNode::~IdNode()
{
    cout << "Deleting a factorNode" << endl;
    delete id;
    id = nullptr;
}
//*****************************************************************************
// Class NestedFactorNode (Nested Factor Node)
class NestedFactorNode : public FactorNode
{
public:
    int operand = 0;
    FactorNode *factorPtr = nullptr;
    // constructor
    NestedFactorNode(int op, FactorNode *fa)
    {
        this->operand = op;
        factorPtr = fa;
    }
    void printTo(ostream &os)
    {
        os << "factor( ";
        if (operand == TOK_NOT)
		{
            os << "NOT ";
		}
        else
		{
            os << "- ";
		}
        os << *factorPtr;
    }
    ~NestedFactorNode();
};
// destructor for FactorNode
NestedFactorNode::~NestedFactorNode()
{
    cout << "Deleting a factorNode" << endl;
    delete factorPtr;
    factorPtr = nullptr;
}
//*****************************************************************************
// Class for TermNode (Term Node)
class TermNode
{
public:
    FactorNode *factorPtr = nullptr;
    // constructor
    TermNode(FactorNode *pFact)
    {
        factorPtr = pFact;
    }
    vector<int> restFactorOps;
    vector<FactorNode *> restFactors;
    ~TermNode();
};
ostream &operator<<(ostream &os, TermNode &node)
{
    os << "term( ";
    os << *(node.factorPtr);

    int length = node.restFactorOps.size();
    for (int i = 0; i < length; ++i)
    {
        int op = node.restFactorOps[i];
        if (op == TOK_MULTIPLY)
		{
            os << " * ";
		}
        else if (op == TOK_DIVIDE)
		{
            os << " / ";
		}
        else
		{
            os << " AND ";
		}
        os << *(node.restFactors[i]);
    }
    os << " )";
    return os;
}
// destructor for TermNode
TermNode::~TermNode()
{
    cout << "Deleting a termNode" << endl;
    delete factorPtr;
    factorPtr = nullptr;
    int length = restFactorOps.size();
    for (int i = 0; i < length; ++i)
    {
        delete restFactors[i];
        restFactors[i] = nullptr;
    }
}
//*****************************************************************************
// Class SimpleExprNode (Simple Expression Node)
class SimpleExprNode
{
public:
    TermNode *termPtr = nullptr;
    // constructor
    SimpleExprNode(TermNode *pTerm)
    {
        termPtr = pTerm;
    }
    vector<int> restTermOps;
    vector<TermNode *> restTerms;
    ~SimpleExprNode();
};
ostream &operator<<(ostream &os, SimpleExprNode &node)
{
    os << "simple_expression( ";
    os << *(node.termPtr);
    int length = node.restTermOps.size();
    for (int i = 0; i < length; ++i)
    {
        int op = node.restTermOps[i];
        if (op == TOK_PLUS)
            os << " + ";
        else if (op == TOK_MINUS)
            os << " - ";
        else
            os << " 0R ";
        os << *(node.restTerms[i]);
    }
    os << " )";
    return os;
}
// destructor for SimpleExprNode
SimpleExprNode::~SimpleExprNode()
{
    cout << "Deleting a simpleExpressionNode" << endl;
    delete termPtr;
    termPtr = nullptr;
    int length = restTermOps.size();
    for (int i = 0; i < length; ++i)
    {
        delete restTerms[i];
        restTerms[i] = nullptr;
    }
}
//*****************************************************************************
// Class ExprNode (Expression Node)
class ExprNode
{
public:
    SimpleExprNode *simpleExpression1Ptr = nullptr;
    SimpleExprNode *simpleExpression2Ptr = nullptr;
    int operand;
    // constructor
    ExprNode(SimpleExprNode *pSimp1)
    {
        simpleExpression1Ptr = pSimp1;
    }
    // constructor for multiple expressions
    ExprNode(SimpleExprNode *pSimp1, int opCode, SimpleExprNode *pSimp2)
    {
        simpleExpression1Ptr = pSimp1;
        operand = opCode;
        simpleExpression2Ptr = pSimp2;
    }
    ~ExprNode();
};
ostream &operator<<(ostream &os, ExprNode &node)
{
    os << *(node.simpleExpression1Ptr);
    if (node.operand == TOK_EQUALTO)
	{
        os << " = ";
	}
    else if (node.operand == TOK_LESSTHAN)
	{
        os << " < ";
	}
    else if (node.operand == TOK_GREATERTHAN)
	{
        os << " > ";
	}
    else if (node.operand == TOK_NOTEQUALTO)
	{
        os << " <> ";
	}
    if (node.simpleExpression2Ptr != nullptr)
	{
        os << *(node.simpleExpression2Ptr);
	}
    return os;
}
// destructor for ExprNode
ExprNode::~ExprNode()
{
    cout << "Deleting an expressionNode" << endl;
    delete simpleExpression1Ptr;
    simpleExpression1Ptr = nullptr;
    delete simpleExpression2Ptr;
    simpleExpression2Ptr = nullptr;
}
//*****************************************************************************
// Class NestedExprNode (Nested Expression Node)
class NestedExprNode : public FactorNode
{
public:
    ExprNode *expressionPtr = nullptr;
    // constructor
    NestedExprNode(ExprNode *ex)
    {
        expressionPtr = ex;
    }
    void printTo(ostream &os)
    {
        os << "nested_expression( expression( " << *expressionPtr;
        os << " )";
    }
    ~NestedExprNode();
};
// destructor for nestedExprNode
NestedExprNode::~NestedExprNode()
{
    cout << "Deleting a factorNode" << endl;

    delete expressionPtr;
    expressionPtr = nullptr;
}
//*****************************************************************************
// Class StatementNode (Statement Node)
class StatementNode
{
public:
    virtual void printTo(ostream &os) = 0;
    virtual ~StatementNode() {}
};
ostream &operator<<(ostream &os, StatementNode &node)
{
    node.printTo(os);
    return os;
}
//*****************************************************************************
// Class AssignmentNode (Assignment Node)
class AssignmentNode : public StatementNode
{
public:
    string *name = nullptr;
    ExprNode *expressionPtr = nullptr;
    // constructor
    AssignmentNode(string id, ExprNode *expr)
    {
        name = new string(id);
        expressionPtr = expr;
    }
    void printTo(ostream &os)
    {
        os << "Assignment " << *name << " := expression( ";
        os << *expressionPtr << " )" << endl;
    }
    ~AssignmentNode();
};
// destructor for AssignmentNode
AssignmentNode::~AssignmentNode()
{
    cout << "Deleting an assignmentNode" << endl;
    delete name;
    name = nullptr;
    delete expressionPtr;
    expressionPtr = nullptr;
}
//*****************************************************************************
// Class ReadNode (Read Node)
class ReadNode : public StatementNode
{
public:
    string *name = nullptr;
    // constructor
    ReadNode(string id)
    {
        this->name = new string(id);
    }
    void printTo(ostream &os)
    {
        os << "Read Value " << *name << endl;
    }
    ~ReadNode();
};
// destructor for ReadNode
ReadNode::~ReadNode()
{
    cout << "Deleting a readNode" << endl;
    delete name;
    name = nullptr;
}
//*****************************************************************************
// Class WriteNode (Write Node)
class WriteNode : public StatementNode
{
public:
    string *name = nullptr;
    int tokenNumber = 0;
    // constructor
    WriteNode(string id, int tokenNum)
    {
        name = new string(id);
        tokenNumber = tokenNum;
    }
    void printTo(ostream &os)
    {
        if (tokenNumber == TOK_STRINGLIT)
		{
            os << "Write String " << *name << endl;
		}
        else
		{
            os << "Write Value " << *name << endl;
		}
    }
    ~WriteNode();
};
// destructor for WriteNode
WriteNode::~WriteNode()
{
    cout << "Deleting a writeNode" << endl;
    delete name;
    name = nullptr;
}
//*****************************************************************************
// Class IfNode (If Node)
class IfNode : public StatementNode
{
public:
    ExprNode *expressionPtr = nullptr;
    StatementNode *thenStatementPtr = nullptr;
    StatementNode *elseStatementPtr = nullptr;
    // constructor
    IfNode(ExprNode *expr, StatementNode *thenState)
    {
        expressionPtr = expr;
        thenStatementPtr = thenState;
    }
    IfNode(ExprNode *expr, StatementNode *thenState, StatementNode *elseState)
    {
        expressionPtr = expr;
        thenStatementPtr = thenState;
        elseStatementPtr = elseState;
    }
    void printTo(ostream &os)
    {
        os << "If expression( ";
        os << *expressionPtr << " )" << endl;
        os << "%%%%%%%% True Statement %%%%%%%%" << endl;
        os << *thenStatementPtr;
        os << "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n";

        if (elseStatementPtr != nullptr)
        {
            os << "%%%%%%%% False Statement %%%%%%%%" << endl;
            os << *elseStatementPtr;
            os << "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n";
        }
    }
    ~IfNode();
};
// destructor for IfNode
IfNode::~IfNode()
{
    cout << "Deleting an ifNode" << endl;
    delete expressionPtr;
    expressionPtr = nullptr;
    delete thenStatementPtr;
    thenStatementPtr = nullptr;
    if (elseStatementPtr != nullptr)
    {
        delete elseStatementPtr;
        elseStatementPtr = nullptr;
    }
}
//*****************************************************************************
// Class WhileNode (While Node)
class WhileNode : public StatementNode
{
public:
    ExprNode *expressionPtr = nullptr;
    StatementNode *loopBody = nullptr;
    // constructor
    WhileNode(ExprNode *expr, StatementNode *loopB)
    {
        expressionPtr = expr;
        loopBody = loopB;
    }
    void printTo(ostream &os)
    {
        os << "While expression( ";
        os << *expressionPtr << " )" << endl;
        os << "%%%%%%%% Loop Body %%%%%%%%" << endl;
        os << *loopBody;
        os << "%%%%%%%%%%%%%%%%%%%%%%%%%%%\n";
    }
    ~WhileNode();
};
// destructor for WhileNode
WhileNode::~WhileNode()
{
    cout << "Deleting a whileNode" << endl;
    delete expressionPtr;
    expressionPtr = nullptr;
    delete loopBody;
    loopBody = nullptr;
}
//*****************************************************************************
// Class CompoundNode
class CompoundNode : public StatementNode
{
public:
    StatementNode *statementPtr = nullptr;
    // constructor
    CompoundNode(StatementNode *mystate)
    {
        statementPtr = mystate;
    }
    vector<StatementNode *> restStatements;
    void printTo(ostream &os)
    {
        os << "Begin Compound Statement" << endl;
        os << *statementPtr;
        int length = restStatements.size();
        for (int i = 0; i < length; ++i)
        {
            StatementNode *sts = restStatements[i];
            os << *sts;
        }
        os << "End Compound Statement" << endl;
    }
    ~CompoundNode();
};
ostream &operator<<(ostream &os, CompoundNode &node)
{
    node.printTo(os);
    return os;
}
// destructor for CompoundNode
CompoundNode::~CompoundNode()
{
    cout << "Deleting a compoundNode" << endl;
    delete statementPtr;
    statementPtr = nullptr;
    int length = restStatements.size();
    for (int i = 0; i < length; ++i)
    {
        delete restStatements[i];
        restStatements[i] = nullptr;
    }
}
//*****************************************************************************
// Class BlockNode (Block Node)
class BlockNode
{
public:
    CompoundNode *compoundStatement = nullptr;
    // constructor
    BlockNode(CompoundNode *compoundPtr)
    {
        this->compoundStatement = compoundPtr;
    }
    ~BlockNode();
};
ostream &operator<<(ostream &os, BlockNode &node)
{
    os << *(node.compoundStatement);
    return os;
}
// destructor for BlockNode
BlockNode::~BlockNode()
{
    cout << "Deleting a blockNode" << endl;
    delete compoundStatement;
    compoundStatement = nullptr;
}
//*****************************************************************************
// Class ProgramNode (Program Node)
class ProgramNode
{
public:
    string *name = nullptr;
    BlockNode *block = nullptr;
    // constructor
    ProgramNode(string id, BlockNode *blk)
    {
        name = new string(id);
        block = blk;
    }
    ~ProgramNode();
};
ostream &operator<<(ostream &os, ProgramNode &node)
{
    os << "Program Name " << *(node.name) << endl;
    os << *(node.block) << endl;
    return os;
}
// destructor for ProgramNode
ProgramNode::~ProgramNode()
{
    cout << "Deleting a programNode" << endl;
    delete name;
    name = nullptr;
    delete block;
    block = nullptr;
}
#endif